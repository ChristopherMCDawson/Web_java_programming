<!--Object system for cars/boats etc.

Christopher Decarie-Dawson
Student:040718315

-->
<head>
<!--Needed tags-->
<meta charset="utf-8">
<meta name ="viewport" content="width=device-width, intitial-scale=1">

<!-- call to Bootstrap CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Lab 7</title> 
</head>



<?php 
include "Header.php"; ?>
    <!-- call menu.php-->
<?php 
include "Menu.php";
?>
<?php
//default parent class to call on
    interface car{
        public function displayCarInfo();

    }class land implements car{
        protected $make;
        protected $model;
        protected $year;
        protected $price;
        function __construct($make, $model, $year, $price){
            $this->make=$make;
            $this->model=$model;
            $this->year=$year;
            $this->price=$price;
        }function displayCarInfo(){
            echo "Make: $this->make, Model: $this->model, Year: $this->year, Price: $this->price,";
        }    
    }
    //landcraft part

    class Lands extends land{
        private $speedLimit;//adds the speedlimit to the system.
        function __construct($make, $model, $year, $price, $speedLimit){
            parent::__construct($make, $model, $year, $price);//calls o nthe parent  for the default.
            $this->setspeedLimit($speedLimit);// setter for the speedlimit
        }function getSpeedLimit(){//getter
            return $this->speedLimit;
        }function setSpeedLimit($speedLimit){ //setter 
             $this->speedLimit = $speedLimit;            
        }public function displayCarInfo(){// display override
            parent::displayCarInfo();
            echo "Speed Limit: ".$this->getSpeedLimit()."</br>";
        } 
        
    }
    // watercraft default parent for  watercraft

    class Boat implements car{
        protected $make;
        protected $model;
        protected $year;
        protected $price;
        function __construct($make, $model, $year, $price) {
            $this->make = $make;
            $this->model = $model;
            $this->year = $year;
            $this->price = $price;            
        }function displayCarInfo(){
            echo "Make: $this->make, Model: $this->model, Year: $this->year, Price: $this->price,";
        }
        
    }class water extends Boat{
        private $boatCapacity;
        function __construct($make, $model, $year, $price, $boatCapacity) {
	        parent::__construct ($make, $model, $year, $price);
	        $this->setBoatCapacity($boatCapacity);//  adds boat cap
	    }function getBoatCapacity() {// getter
            return $this->boatCapacity;
        }function setBoatCapacity($boatCapacity) {//setter
            $this->boatCapacity = $boatCapacity;
        }public function displayCarInfo() { //display override  
	        parent::displayCarInfo();
	        echo " Boat Capacity: ".$this->getBoatCapacity()."</br>";
	    } 
    }// Car and boat display things
    echo "<h2><b><u>Car</h2></b></u>";

    $car1 = new Lands("Toyota", "Camry", 1992, 2000, 180);
    $car2 = new Lands("Honda", "Accord", 2002, 6000, 200);

    $car1->displayCarInfo();
    $car2->displayCarInfo();

    echo "<h2><u>Boat</h2></u>";

    $boat1 = new water("Mitsubishi", "Turbo", 1999, 20000, 18);
    $boat2 = new water("Hyundai", "XT", 2012, 26000, 8);

    $boat1->displayCarInfo();
    $boat2->displayCarInfo();
?>
    <!-- Call to footer.php-->
    <?php 
    include "Footer.php";
    ?>   