<!--Main website page, first one displayed

Christopher Decarie-Dawson
Student:040718315

-->



<!doctype html>
<html lang="en">

<head>
<!--Needed tags-->
<meta charset="utf-8">
<meta name ="viewport" content="width=device-width, intitial-scale=1">

<!-- call to Bootstrap CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Lab 7</title> 
</head>
 

 
 <!-- call to header.php-->
 <body>
<?php 
include "Header.php"; ?>
    <!-- call menu.php-->
<?php 
include "Menu.php";
?>

<?php
    $november = [// to setup the print out
        "Friday"=> ["1st" =>5 ,"2nd"=>12, "3rd"=>19, "4th"=>26],
        "Saturday" => ["1st" => 6, "2nd" => 13, "3rd" => 20, "4th" => 27],
        "Sunday" => ["1st" => 7, "2nd" => 14, "3rd" => 21, "4th" => 28],
        "Monday" => ["1st" => 1, "2nd" => 8, "3rd" => 15, "4th" => 22, "5th" => 29],
        "Tuesday" => ["1st" => 2, "2nd" => 9, "3rd" => 16, "4th" => 23, "5th" => 30],
        "Wednesday" => ["1st" => 3, "2nd" => 10, "3rd" => 17, "4th" => 24],
        "Thursday" => ["1st" => 4, "2nd" => 11, "3rd" => 18, "4th" => 25]

    ];

    echo"<h2> Output 1 </h2><br>";
    print_r($november);// output 1 print out
    echo"<h2> Output 2 </h2><br>";
    $thing = array_keys($november);// adding the extra day  printout
    for($i=0;$i<count($november);$i++){
        foreach($november[$thing[$i]]as$index =>$element){
            echo "$element is the $index $thing[$i] in November.<br>";
        }
    }echo"<h2> Output 3 </h2><br>";
    print_r(array_reverse($november));

    echo"<h2> Output 3 </h2><br>";
    $november["Wednesday"]+=["5th"=>31];
    print_r($november);

?>

    <!-- Call to footer.php-->
    <?php 
    include "Footer.php";
    ?>   
    </body>
</html>