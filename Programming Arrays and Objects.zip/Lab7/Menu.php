<!-- Hyper links

Christopher Decarie-Dawson
Student:040718315

-->

<div class="hyperLinks text-end">
            <ul class="nav justify-content-end"> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab7/Array.php">Array</a>
                  </li> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab7/Calculator.php">Calculator</a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab7/Objects.php">Objects</a>
                  </li>
                </ul>               
                   
    </nav>
</div>