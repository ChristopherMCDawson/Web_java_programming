<!--Calculator page

Christopher Decarie-Dawson
Student:040718315

-->
<head>
<!--Needed tags-->
<meta charset="utf-8">
<meta name ="viewport" content="width=device-width, intitial-scale=1">

<!-- call to Bootstrap CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Lab 7</title> 
</head>




<?php 
include "Header.php"; ?>
    <!-- call menu.php-->
<?php 
include "Menu.php";
?> 
    <form action="Calculator.php" method ="GET"> <!--Sets up the buttons for use -->
    <input type="number"name="number1">
    <select id="math"name="math">
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
        <option value="^">^</option>
    </select>
    <input type="number"name="number2">
    <input type="submit"value="=">
    </form>

<?php
    function prime($result){// prime number checker
        $check = true;
        for($i=2;$i<=$result/2;$i++){
            if($result % $i == 0){
                $check = false;
            }
        }if($check){
            echo "</br>$result is prime </br>";
        }else{
            echo "</br>$result is  not prime </br>";
        }    
        
    }
    function eveOdd($result){// Even odd Checker.
        if($result%2==0){
            echo"$result is Even </br>";
        }else{
            echo"$result is Odd </br>";
        }
    }

    $result = 0;
    $number1 = $_GET["number1"];
    $number2 = $_GET["number2"];

    switch($_GET["math"]) {// outputs for the system depending on the type of eqasian used.
        case '+':
            $result = $number1 + $number2;
            echo "$number1 plus $number2 equals $result</br>";
            Prime($result);
            eveOdd($result);
            break;
        case '-':
            $result = $number1 - $number2;
            echo "$number1 minus $number2 equals $result</br>";
            prime($result);
            eveOdd($result);
            break;
        case '*':
            $result = $number1 * $number2;
            echo "$number1 multiplied by $number2 equals $result</br>";
            prime($result);
            eveOdd($result);
            break;
        case '/':
            $result = $number1 / $number2;
            echo "$number1 divided by $number2 equals $result</br>";
            prime($result);
            eveOdd($result);
            break;
        case '^':
            $result = pow($number1, $number2);
            echo "$number1 to the power of $number2 equals $result</br>";
            prime($result);
            eveOdd($result);
            break;
        default:
                echo "Wrong operator";

    }
?>
    <!-- Call to footer.php-->
    <?php 
    include "Footer.php";
    ?>   