<!--When called on iot will display the requested info from the employee array.
Christopher Decarie-Dawson
-->
<?php
session_start();// starts the session when called on.
if(isset($_SESSION["employee"])){
    $employees = $_SESSION["employee"];
} else {
    $employees = null;
}
?>
		<?php // calls the header and menu
		  include_once "header.php";
		  include_once "menu.php";
		?>	
	<div id="content">
	<div id="content1">
		        <?php	// content1 when called on format.	        
		        if(count($employees) > 0){
                    echo "First Name: ".$employees['FirstName']."<br>";
                    echo "Last Name: ".$employees['LastNam']."<br>";
                    echo "Email Address: ".$employees['EmailAddress']."<br>";
                    echo "Phone Number: ".$employees['TelephoneNumber']."<br>";
                    echo "Social Insurance Number: ".$employees['SocialInsuranceNumber']."<br>";
                    echo "Password: ".$employees['Password']."<br>";
            } else {// empty file catch.
                echo "No session was saved";
            }             
        ?>
        </div>
	<div id="content2">
	<?php // content2 when called on format
	require "SQLConnection.php";
	try {// try /catch for error messaging and looping.
	    $object = new PDO("mysql:host=$host;dbname=$database", $username, $password);
	    $object->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	   
	    
	    $query = "SELECT * FROM employee";
	    $result = $object->query( $query );
	    $rowCount = $result->rowCount();
	    $columnCount =$result->columnCount();
	    if ($rowCount > 0){
	        echo "<table> <tr>";
	        echo "<th>First Name</th>";
	        echo "<th>Last Name</th>";
	        echo "<th>Email Address</th>";
	        echo "<th>Phone Number</th>";
	        echo "<th>Social Insurance number</th>";
	        echo "<th>Password</th></tr>";
	        for($i = 0 ; $i < $rowCount; ++$i)
	        {
	            $row = $result->fetch();
	            for ($j = 1; $j < $columnCount; $j++){
	                echo "<th>$row[$j]</th>";
	            }	            
	                echo "</tr>";
	        }
	        echo "</table>";                        
	    } else {
	        echo "==== No information is available for display ====";
	    }	    
	    $object = null;
	}	
	catch(PDOException $e) {// error message
	    echo "Failed to establish connection:  " . $e->getMessage();
	}	
	?>
	</div>
  </div>
			
		<?php 
		include_once "footer.php";
		?>