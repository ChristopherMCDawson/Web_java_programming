<?php
$host = "localhost";
$username = "uv7powgmvikal";
$password = "omk2kunedwdc";
$database = "dbdfjndrlqryiw";
?>