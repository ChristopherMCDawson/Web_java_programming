    <!--Footer info , student name etc.
Christopher Decarie-Dawson
Student:040718315


-->
   <div class="jumbotron bg-secondary text-center h5">
    <footer>
        Student Number:040718315
        <br>First Name: Christopher
        <br>Last Name: Decarie-Dawson
        <br>
        <a href="mailto:deca0058@algonquinlive.com">deca0058@algonquinlive.com</a>
</footer>
</div>
</body>
  
  </html>