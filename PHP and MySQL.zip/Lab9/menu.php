<!-- Hyper links
Christopher Decarie-Dawson
Student:040718315
-->
<div class="hyperLinks text-end">
            <ul class="nav justify-content-end"> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab9/login.php">Login</a>
                  </li> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab9/createaccount.php">Create Account</a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab9/viewallemployees.php">View Employees</a>
                  </li>
                </ul>               
                   
    </nav>
</div>