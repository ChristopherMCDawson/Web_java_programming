<!--login for users with accounts already requesting login email and password
Christopher Decarie-Dawson
-->
<?php
session_start();// starts the session for this login.php page.


if (isset($_POST['Email']))  {
    retrieveInfo();
}

function retrieveInfo() {
    require_once "SQLConnection.php";// calls to the SQL  for the employee array.
    $employees = array();
    try {
        $object = new PDO("mysql:host=$host;dbname=$database", $username, $password);
        $object->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $query = "SELECT * FROM employee WHERE EmailAddress ='".$_POST['EmailAddress']."' AND Password='".$_POST['Password']."'";        
        $result = $object->query( $query );
        $rowCount = $result->rowCount();
        if ($rowCount > 0){
            $employees = array();
            for($i = 0; $i < $rowCount; ++$i)
            {
                $row = $result->fetch();
                $employees['FirstName'] = $row[1];
                $employees['LastNam'] = $row[2];
                $employees['EmailAddress'] = $row[3];
                $employees['TelephoneNumber'] = $row[4];
                $employees['SocialInsuranceNumber'] = $row[5];
                $employees['Password'] = $row[6];
             }
            $_SESSION["employee"] = $employees;
            header("Location: viewallemployees.php");
            exit;
        } else {
            echo "==== Nothing to display ====";
        }
        
        $object = null;
    }
    
    catch(PDOException $e) {
        echo "Connection failed:  " . $e->getMessage();
    }
    
}
?>
		<?php //whats displayed to the user.
		  include_once "header.php";
		  include_once "menu.php";
		?>	
	<div id="content">	
	<form action="login.php" method="post" >
	 Email Address: <INPUT TYPE = "Text" NAME= "EmailAddress" required><br>
	 Password: <INPUT TYPE = "password" NAME= "Password" required><br>
	 <input type="submit" value="Submit Information">
	 </form>
         
    </div>
		<?php 
		include_once "footer.php";
		?>
	