<!--Code to create an account on the website
Christopher Decarie-Dawson

-->


<?php
session_start();// need to start the session.


if (isset($_POST['FirstName']))  {
    saveInfo();
}

function saveInfo() {  // an array to taking in and store the employee info.  
    $employees=array();
    $employees['FirstName']=$_POST['FirstName'];
    $employees['LastNam']=$_POST['LastNam'];
    $employees['EmailAddress']=$_POST['EmailAddress'];
    $employees['TelephoneNumber']=$_POST['TelephoneNumber'];
    $employees['SocialInsuranceNumber']=$_POST['SocialInsuranceNumber'];
    $employees['Password']=$_POST['Password'];
    try {
        require_once "SQLConnection.php";
        $object = new PDO("mysql:host=$host;dbname=$database", $username, $password);
        $object->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        
        $query = "INSERT INTO employee (FirstName, LastNam, EmailAddress, TelephoneNumber, SocialInsuranceNumber, Password) VALUES('".$employees['FirstName']."', '".$employees['LastNam']."',
                                  '".$employees['EmailAddress']."','".$employees['TelephoneNumber']."','".$employees['SocialInsuranceNumber']."','".$employees['Password']."')";
        
        try {
            $result = $object->query( $query );
            echo "Employee added successfully!". "<br>";
        }        catch(PDOException $e) {
            echo "Error in addition of employee:  " . $e->getMessage();
        }        
        $object = null; }    
    catch(PDOException $e) {
        echo "Failed to establish connection:  " . $e->getMessage();
    }
    $_SESSION["employee"] = $employees;
    header("Location: viewallemployees.php");// sending all the input info to the viewallemployees.php.
    exit;       
}

//  displays the requested info  and makes them required to conutine.
?>		<?php 
		  include_once "header.php";
		  include_once "menu.php";
		?>

	<div id="content">
	
	<form action="createaccount.php" method="post" >
	Fill the form below<br>
	First Name: <INPUT TYPE = "Text" NAME= "FirstName" required><br>
	Last Name: <INPUT TYPE = "Text" NAME= "LastNam" required><br>
	Email Address: <INPUT TYPE = "Text" NAME= "EmailAddress" required><br>
	Telephone Number: <INPUT TYPE = "Text" NAME= "TelephoneNumber" required><br>
	Social Insurance Number: <INPUT TYPE = "Text" NAME= "SocialInsuranceNumber" required><br>
	Password: <INPUT TYPE = "password" NAME= "Password" required><br>

	 <input type="submit" value="Submit Information">
	 </form>

         
        </div>
			

		<?php 
		include_once "footer.php";
		?>
