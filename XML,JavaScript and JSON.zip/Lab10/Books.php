<?php
$q=$_GET("q");
$y="";
$xml =file_get_contents("Books.xml");

$xmlDOM =new DOMDocument();
$xmlDOM->loadXML($xml);

$book =$xmlDOM->getElementsByTagName('book');
$i=0;
$y=array();
foreach($book as $catalog)
{
    foreach($catalog->childNodes as $nods)
    { if ($node->nodeNmae=="genre")
        { if ($node->nodeValue==$q)
            {
                $y[$i]=($node->parentNode);
                $i++;
            }
        }
    }
}for ($j=0;$j<$i;$j++) {
    foreach($y[$j]->childNodes as $node)
    {   if ($node->nodeName == "author")
        {   echo("<b>".$node->nodeName.":</b> ");
            echo($node->nodeValue);
            echo("<br>");
        }        
        if ($node->nodeName == "title")
        {   echo("<b>".$node->nodeName.":</b> ");
            echo($node->nodeValue);
            echo("<br>");
        }        
        if ($node->nodeName == "genre")
        {   echo("<b>".$node->nodeName.":</b> ");
            echo($node->nodeValue);
            echo("<br>");
        }        
        if ($node->nodeName == "price")
        {   echo("<b>".$node->nodeName.":</b> ");
            echo($node->nodeValue);
            echo("<br>");
        }        
        if ($node->nodeName == "publish_date")
        {   echo("<b>".$node->nodeName.":</b> ");
            echo($node->nodeValue);
            echo("<br>");
        }        
        if ($node->nodeName == "description")
        {   echo("<b>".$node->nodeName.":</b> ");
            echo($node->nodeValue);
            echo("<br>");
        }    
    }
    echo "<br>";
}
?>