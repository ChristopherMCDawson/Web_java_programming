
<!-- Hyper links-->

<div class="hyperLinks text-end">
            <ul class="nav justify-content-end"> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab2/index.html">Lab2</a>
                  </li> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab3/index.html">Lab3</a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/lab4/index.html">Lab4</a>
                  </li>
                </ul>               
                   
    </nav>
</div>