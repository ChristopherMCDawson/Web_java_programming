<!doctype html>
<html lang="en">

<head>
<!--Needed tags-->
<meta charset="utf-8">
<meta name ="viewport" content="width=device-width, intitial-scale=1">

<!-- call to Bootstrap CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Lab 5</title>
</head>


<!--middle assignment name-->
<body>
        <!-- call to header.php-->
    <?php 
        include "header.php";
    ?>
    <!-- call menu.php-->
 <?php 
        include "menu.php";
    ?>



   <div class="jumbotron">
         <main class="boarder border-secondary">
            <div>
             <h4>Lab 5</h4>
             <!-- Php code -->
                <?php
                    $first ='Christopher';
                    $last ='Decarie-Dawson';
                    define("Student","040718315");

                    echo 'First name: '.$first.'<br>'.'Last name: '.$last.'<br>';
                    echo 'Student ID: '.Student.'<br>';

                    date_default_timezone_set('America/Toronto');
                    $today = date("y-m-d");
                    echo "Today's date: ".$today.'<br>';
                    $Tday = date("h:m:s");
                    echo "Time of day: ".$Tday.'<br>';

                    $Nextday = strtotime("+1 day");
                  
                    echo "Tomorrow is: ".date("Y-m-d",$Nextday).'<br>';

                    $nextmon = strtotime("next Monday");
                    echo "Next Monday is: ".date("Y-m-d",$nextmon).'<br>';

                ?>
            </div>
        </main>
     

    <!-- Call to footer.php-->
    <?php 
    include "footer.php";
    ?>   

  
</body>
</html>