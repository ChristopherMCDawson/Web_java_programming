<!-- Hyper links-->

<div class="hyperLinks text-end">
            <ul class="nav justify-content-end"> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab 6/all.php">ALL</a>
                  </li> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab 6/ramdom.php">Random</a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab 6/pattern.php">Pattern</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab 6/ten.php">Ten</a>
                  </li> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab 6/evenodd/php">Evenodd</a>
                  </li> 
                </ul>               
                   
    </nav>
</div>