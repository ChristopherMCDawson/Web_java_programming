<!--  header and menu to nav to other links within the website.-->
<?php include "Header.php"?>
<?php include "Menu.php"?>

<?php 

for($i =1;$i<=20;$i++){
    for($j=$i;$j<20;$j++){
        
        echo "&nbsp&nbsp"; // used to add addtional spoane btween the words, help make it look better
    }for($j=(2*$i)-1;$j>0;$j--){
        echo "&nbsp*";
    }
    echo"<br>";
}
$b=20;
for($i =20;$i>0;$i--){
    for($j=$b-$i;$j>0;$j--){
        echo "&nbsp&nbsp";
    }
    for($j=(2*$i)-1;$j>0;$j--){
        echo "&nbsp*";
    }
    echo "<br>";
}
?>
   <!-- Call to footer.php-->
   <?php 
    include "Footer.php";
    ?>   