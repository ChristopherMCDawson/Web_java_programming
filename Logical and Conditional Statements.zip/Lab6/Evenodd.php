<!--  header and menu to nav to other links within the website.-->
<?php include "Header.php"?>
<?php include "Menu.php"?>

<?php
for($i=99;$i>1;$i--){
    if(($i%2)!=0){
        echo"$i bottles of beer can serve an off number of guests... <br>";
    }else{
        echo "$i bottles of beer can serve an even number of guests... <br>";
    }
    if(($i -1 )==1){
        echo "1 bottle of beer can serve Only One guest... <br>";
    }
}





?>
   <!-- Call to footer.php-->
   <?php 
    include "Footer.php";
    ?>   