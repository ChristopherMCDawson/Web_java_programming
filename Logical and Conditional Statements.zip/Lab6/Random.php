<!--  header and menu to nav to other links within the website.-->
<?php include "Header.php"?>
<?php include "Menu.php"?>

<?php 

$One =0;//10
$Two =0;//20
$Three =0;// 30
$Four =0;// 40
$Five =0;// 50

for($i =1;$i<=500;$i++){// keeps it in the ranges
    $randNum =rand(1,50);
    if($randNum>=1&&$randNum<=10){
        $One++;
    }else if($randNum>=11&&$randNum<=20){
        $Two++;
    } else if($randNum>=21&&$randNum<=30){
        $Three++;
    } else if($randNum>=31&&$randNum<=40){
        $Four++;
    } else if($randNum>=41&&$randNum<=50){
        $Five++;
    }
}
    echo "$One numbers are randomly generated in the range between 01 - 10 <br>";
    echo "$Two numbers are randomly generated in the range between 11 - 20 <br>";
    echo "$Three numbers are randomly generated in the range between 21 - 30 <br>";
    echo "$Four numbers are randomly generated in the range between 31 - 40 <br>";
    echo "$Five numbers are randomly generated in the range between 41 - 50 <br>";

    function histogram($type, $shape){// used to print the shape in *
        echo"$type: ";
        for($i=1;$i<=$shape;$i++){
            echo "*";
        }
        echo"<br>";
    }
    histogram("01-10", ($One/500)*100);
    histogram("11-20", ($Two/500)*100);
    histogram("21-30", ($Three/500)*100);
    histogram("31-40", ($Four/500)*100);
    histogram("41-50", ($Five/500)*100);
?>
   <!-- Call to footer.php-->
   <?php 
    include "Footer.php";
    ?>   