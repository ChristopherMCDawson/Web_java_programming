<!doctype html>
<html lang="en">

<head>
<!--Needed tags-->
<meta charset="utf-8">
<meta name ="viewport" content="width=device-width, intitial-scale=1">

<!-- call to Bootstrap CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Lab 6</title> 
</head>
 

 
 <!-- call to header.php-->
 <body>
<?php 
include "Header.php"; ?>
    <!-- call menu.php-->
<?php 
include "Menu.php";
?>

<?php

for($i=99;$i>=3;$i--){
    echo "$i Bottles of beer on the wall...  <br>";
    echo "$i Bottles of beer...  <br>";
    echo "You take one down pass it around... <br>";
    $next = $i -1;
    echo "$next Bottles of beer on the wall. <br><br>";
}
for($i = 2;$i>0;$i--){
    $beers = $i -1;
    if($i==2){
     echo"$i bottles of beer on the wall... <br>";
       echo "$i Bottles of beer...  <br>";
         echo "You take one down pass it around... <br>";
         echo"$beers bottles of beer on the wall <br><br>";


    }if($i==1){
        echo"$i bottles of beer on the wall... <br>";
        echo "$i Bottles of beer...  <br>";
        echo "You take one down pass it around... <br>";
        echo"$beers bottles of beer on the wall <br><br>";

    }if($beers ==0){
        echo"There are no more bottles of beer on the wall <br>";
    }
}

?>

    <!-- Call to footer.php-->
    <?php 
    include "Footer.php";
    ?>   
    </body>
</html>