<!--  header and menu to nav to other links within the website.-->    
<?php include "Header.php"?>
<?php include "Menu.php"?>

<?php 
for($i=90;$i>=20;$i-=10){
    echo "$i Bottles of beer on the wall...  <br>";
    echo "$i Bottles of beer...  <br>";
    echo "You take one down pass it around... <br>";
    $next = $i -10;
    echo "$next Bottles of beer on the wall. <br><br>";
}
for($i=10;$i>0;$i-=10){
    $beers = $i -10;
    echo"$i bottles of beer on the wall... <br>";
    echo "$i Bottles of beer...  <br>";
      echo "You take one down pass it around... <br>";
      echo"$beers bottles of beer on the wall <br><br>";

      if($beers ==0){
          echo"There are no more bottles of beer on the wall <br>";
      }
}
?>

 <!-- Call to footer.php-->
 <?php 
    include "Footer.php";
    ?>   