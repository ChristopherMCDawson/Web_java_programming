<!-- Hyper links

Christopher Decarie-Dawson
Student:040718315

-->

<div class="hyperLinks text-end">
            <ul class="nav justify-content-end"> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab08/Input.php">Input</a>
                  </li> 
                  <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab08/Session1.php">Session1</a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="https://christopherd2.sgedu.site/Lab08/Session2.php">Session2</a>
                  </li>
                </ul>               
                   
    </nav>
</div>