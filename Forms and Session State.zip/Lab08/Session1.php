<?php include "header.php" ?>
<?php include "menu.php" ?>

<head>
<!--Needed tags-->
<meta charset="utf-8">
<meta name ="viewport" content="width=device-width, intitial-scale=1">

<!-- call to Bootstrap CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" 
integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="style.css" />
<title>Lab 8</title> 
</head> 
 <!-- call to header.php-->
 <body>




<?php
session_start();
$employeeName = $email = $post = $employeeID = $phone =  "";
$project = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $employeeName = ($_POST["employeeName"]);
        $employeeID = ($_POST["employeeID"]);
        $email = ($_POST["email"]);
        $phone =($_POST["phone"]);
        $post = ($_POST["post"]);
        $project = ($_POST['Project']);
        $_SESSION["employeeName"] = $employeeName;
        $_SESSION["employeeID"] = $employeeID;
        $_SESSION["email"] = $email;
        $_SESSION["phone"] = $phone;
        $_SESSION["post"] = $post;
        $_SESSION["project"] = $project;
    
    header("Location: session02.php");
    exit;
    
}
?>			
	<div class="row">
	<div class="column">	
	<form action="session01.php" method="post" >
			
Employee Name: <input type="text" name="employeeName" value="<?php echo $employeeName;?>">
<br><br>
Employee ID: <input type="text" name="employeeID" value="<?php echo $employeeID;?>">
<br><br>
Telephone Number: <input type="text" name="phone" value="<?php echo $phone;?>">
<br><br>
E-mail: <input type="text" name="email" value="<?php echo $email;?>">
<br><br>

Post:
<input type="radio" name="post" <?php if (isset($post) && $post == "Manager") echo "checked";?> value="manager">Manager
<input type="radio" name="post" <?php if (isset($post) && $post == "TeamLead") echo "checked";?> value="Team Lead">Team Lead
<input type="radio" name="post" <?php if (isset($post) && $post == "itDeveloper") echo "checked";?> value="IT Developer">IT Developer
<input type="radio" name="post" <?php if (isset($post) && $post == "itAnalyst") echo "checked";?> value="IT Analyst">IT Analyst
<br><br>
<label for="project">Choose a project: </label>
<select name="Project[]" id="project" multiple>
<option value="Project A">Project A</option>
<option value="Project B">Project B</option>
<option value="Project C">Project C</option>
<option value="Project D">Project D</option>

</select>
<br><br>			
<input type="submit" name="submit" value="Submit Information">
</form>

</div>
</div>
<?php include "footer.php" ?>
</body>
</html>


