<?php include "header.php" ?>
<?php include "menu.php" ?>

<head>
<!--Needed tags-->
<meta charset="utf-8">
<meta name ="viewport" content="width=device-width, intitial-scale=1">

<!-- call to Bootstrap CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" 
integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="style.css" />
<title>Lab 8</title> 
</head> 
 <!-- call to header.php-->
 <body>







<?php

session_start();
if (isset($_SESSION["employeeID"])) {
$employeeName = $_SESSION["employeeName"];
$employeeID = $_SESSION["employeeID"];
$email = $_SESSION["email"];
$phone = $_SESSION["phone"];
$post = $_SESSION["post"];
$project = array();
$project = $_SESSION["project"];

} else {
    echo "No session is active";
}


?>		
	<div class="row">
	
	<?php 	
	echo "<h2>Submitted Information</h2>";
	echo "<label>Employee Name: ".$employeeName."</label>";	
	echo "<br>";	
	echo "<label>Employee ID: ".$employeeID."</label>";	
	echo "<br>";	
	echo "<label>Telephone Number: ".$phone."</label>";	
	echo "<br>";	
	echo "<label>Email Address: ".$email."</label>";	
	echo "<br>";	
	echo "<label>Post: ".$post."</label>";	
	echo "<br>";	
	foreach ($project as $p){
	    echo "<label>Project: ".$p."</label>";
	}
	?>

</div>
<?php include "footer.php" ?>
</body>
</html>