/*Christopher Decarie-Dawson
 *date:2023-06-23
 *Student#:040718315
 *BouncerGame.java
 *###################################
 *When the "game" is running this should update the bouncer's location and speed
 * But does not.
 */
package cst8218.deca0058.bouncer;

import cst8218.deca0058.bouncer.entity.Bouncer;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Startup
@Singleton
public class BouncerGame {

    @Inject
    private cst8218.deca0058.bouncer.presentation.BouncerFacade bouncerFacade;
    private List<Bouncer> bouncers;
    private final static int CHANGE_RATE = 10;

    @PostConstruct
    public void go() {
        new Thread(new Runnable() {
            public void run() {
                // the game runs indefinitely
                
                while (true) {
                    //update all the bouncers and save changes to the database
                    bouncers = bouncerFacade.findAll();
                    for (Bouncer bouncer : bouncers) {
                        bouncer.advanceOneFrame();
                        bouncerFacade.edit(bouncer);
                    }
                    //sleep while waiting to process the next frame of the animation
                    try {
                        // wake up roughly CHANGE_RATE times per second
                        Thread.sleep((long) (1.0 / CHANGE_RATE * 1000));
                    } catch (InterruptedException exception) {
                        exception.printStackTrace();
                    }
                }
            }
        }).start();
}

}

