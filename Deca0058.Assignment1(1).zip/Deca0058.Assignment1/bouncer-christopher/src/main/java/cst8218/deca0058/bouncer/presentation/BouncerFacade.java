/*Christopher Decarie-Dawson
 *date:2023-06-23
 *Student#:040718315
 *BouncerFacade.java
 *###################################
 *Nothing has been added or changed to this class.
 */
package cst8218.deca0058.bouncer.presentation;

import cst8218.deca0058.bouncer.entity.Bouncer;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Christopher Decarie-Dawson
 */
@Stateless
public class BouncerFacade extends AbstractFacade<Bouncer> {

    @PersistenceContext(unitName = "bouncer_persistence_unit")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public BouncerFacade() {
        super(Bouncer.class);
    }

  
    
}
