/*Christopher Decarie-Dawson
 *date:2023-06-23
 *Student#:040718315
 *Bouncer.java
 *###################################
 *Holds all the base structure to create a Bouncer ti be used in the BouncerGame.
 */
package cst8218.deca0058.bouncer.entity;

import cst8218.deca0058.bouncer.BouncerGame;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Christopher Decarie-Dawson
 */
@Entity
@XmlRootElement
public class Bouncer implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Min(0)
    @Max(FRAME_WIDTH)
    private Integer x;
    
    @Min(0)
    @Max(FRAME_HEIGHT)
    private Integer y;
    
    private Integer ySpeed;
    
    private static final int FRAME_WIDTH = 500; //desired frame width
    private static final int FRAME_HEIGHT = 500; //desired frame height
    private static final int GRAVITY_ACCEL = 5;
    private static final int DECAY_RATE = 1;
    
    public static final int CHANGE_RATE = 1; //change rate in frames per second

    public Bouncer() {
        // Default constructor
    }

    public Bouncer(Integer x, Integer y, Integer ySpeed) {
        this.x = x;
        this.y = y;
        this.ySpeed = ySpeed;
    }
    
      public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Integer getYSpeed() {
        return ySpeed;
    }

    public void setYSpeed(Integer ySpeed) {
        this.ySpeed = ySpeed;
    }
    // Logic I wrote to advance the"frame" or unit of time by one so that the
    //valuse first given will move, change.
   public void advanceOneFrame() {
    if (ySpeed != 0 || y != FRAME_HEIGHT) {
        ySpeed += GRAVITY_ACCEL;
    }
    
    y += ySpeed;
    
    if (y >= FRAME_HEIGHT && ySpeed > 0) {
        ySpeed = -Math.abs(ySpeed) + DECAY_RATE;
    }
    
    if (y <= 0 && ySpeed < 0) {
        ySpeed = Math.abs(ySpeed) + DECAY_RATE;
    }
}

    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bouncer)) {
            return false;
        }
        Bouncer other = (Bouncer) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Bouncers.Bouncer[ id=" + id + " ]";
    }

 
}
